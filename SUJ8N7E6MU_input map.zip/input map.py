input_dic  ={101:"john Doe",102:"Jane Smith", 103:"Peter Johson"}

sorted_dic = dict(sorted(input_dic.items(),key = lambda item: item[1]))


print("Sorted Dictionary:",sorted_dic)